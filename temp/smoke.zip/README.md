Smoke test
